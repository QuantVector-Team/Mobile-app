import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/user_model.dart';
import '../models/backtest_result.dart';
import '../models/history_item.dart';

class ApiService {
  // ⚠️ ЗАМЕНИ на адрес своего сервера
  static const String baseUrl = 'https://your-server.com/api';

  // Регистрация
  static Future<UserModel> register(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    final data = jsonDecode(response.body);
    if (data['status'] == 'success') {
      return UserModel.fromJson(data);
    }
    throw Exception(data['message'] ?? 'Ошибка регистрации');
  }

  // Вход
  static Future<UserModel> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    final data = jsonDecode(response.body);
    if (data['status'] == 'success') {
      return UserModel.fromJson(data);
    }
    throw Exception(data['message'] ?? 'Неверный логин или пароль');
  }

  // Запустить бэктест
  static Future<BacktestResult> runBacktest({
    required String token,
    required String symbol,
    required String timeframe,
    required String strategyName,
    required int fastPeriod,
    required int slowPeriod,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/backtest'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'token': token,
        'symbol': symbol,
        'timeframe': timeframe,
        'strategy': {
          'name': strategyName,
          'fast_period': fastPeriod,
          'slow_period': slowPeriod,
        },
      }),
    );
    final data = jsonDecode(response.body);
    if (data['status'] == 'success') {
      return BacktestResult.fromJson(data);
    }
    throw Exception(data['message'] ?? 'Ошибка запуска бэктеста');
  }

  // История стратегий
  static Future<List<HistoryItem>> getHistory(String token, {int limit = 20}) async {
    final response = await http.post(
      Uri.parse('$baseUrl/history'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'token': token, 'limit': limit}),
    );
    final data = jsonDecode(response.body);
    if (data['status'] == 'success') {
      return (data['data'] as List)
          .map((e) => HistoryItem.fromJson(e))
          .toList();
    }
    throw Exception(data['message'] ?? 'Ошибка загрузки истории');
  }
}
