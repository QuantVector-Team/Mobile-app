class BacktestResult {
  final double profitPercent;
  final int totalTrades;
  final double winRate;
  final List<EquityPoint> equityCurve;

  BacktestResult({
    required this.profitPercent,
    required this.totalTrades,
    required this.winRate,
    required this.equityCurve,
  });

  factory BacktestResult.fromJson(Map<String, dynamic> json) {
    final summary = json['summary'];
    return BacktestResult(
      profitPercent: (summary['profit_percent'] as num).toDouble(),
      totalTrades: summary['total_trades'],
      winRate: (summary['win_rate'] as num).toDouble(),
      equityCurve: (json['equity_curve'] as List)
          .map((e) => EquityPoint.fromJson(e))
          .toList(),
    );
  }
}

class EquityPoint {
  final int time;
  final double balance;

  EquityPoint({required this.time, required this.balance});

  factory EquityPoint.fromJson(Map<String, dynamic> json) {
    return EquityPoint(
      time: json['time'],
      balance: (json['balance'] as num).toDouble(),
    );
  }
}
