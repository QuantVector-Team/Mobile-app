class HistoryItem {
  final int testId;
  final String date;
  final String symbol;
  final String strategyName;
  final double profitPercent;

  HistoryItem({
    required this.testId,
    required this.date,
    required this.symbol,
    required this.strategyName,
    required this.profitPercent,
  });

  factory HistoryItem.fromJson(Map<String, dynamic> json) {
    return HistoryItem(
      testId: json['test_id'],
      date: json['date'],
      symbol: json['symbol'],
      strategyName: json['strategy_name'],
      profitPercent: (json['profit_percent'] as num).toDouble(),
    );
  }
}
