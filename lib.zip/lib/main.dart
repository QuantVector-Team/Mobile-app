import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'theme.dart';
import 'screens/login_screen.dart';
import 'screens/backtest_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CryptoBacktestApp());
}

class CryptoBacktestApp extends StatelessWidget {
  const CryptoBacktestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Crypto Backtest',
      theme: AppTheme.theme,
      debugShowCheckedModeBanner: false,
      home: const _SplashDecider(),
    );
  }
}

// Проверяем, есть ли сохранённый токен
class _SplashDecider extends StatefulWidget {
  const _SplashDecider();

  @override
  State<_SplashDecider> createState() => _SplashDeciderState();
}

class _SplashDeciderState extends State<_SplashDecider> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    await Future.delayed(const Duration(milliseconds: 500));
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => token.isNotEmpty
            ? BacktestScreen(token: token)
            : const LoginScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(color: Color(0xFF9B59FF)),
      ),
    );
  }
}
