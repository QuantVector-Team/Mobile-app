import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../theme.dart';
import '../models/backtest_result.dart';

class ResultScreen extends StatelessWidget {
  final BacktestResult result;
  final String symbol;
  final String strategy;

  const ResultScreen({
    super.key,
    required this.result,
    required this.symbol,
    required this.strategy,
  });

  @override
  Widget build(BuildContext context) {
    final isProfit = result.profitPercent >= 0;
    final profitColor = isProfit ? AppTheme.green : AppTheme.red;

    return Scaffold(
      appBar: AppBar(title: Text('$symbol — $strategy')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Главная карточка прибыли
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: profitColor.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Text('Результат', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                  const SizedBox(height: 8),
                  Text(
                    '${isProfit ? '+' : ''}${result.profitPercent.toStringAsFixed(2)}%',
                    style: TextStyle(color: profitColor, fontSize: 48, fontWeight: FontWeight.w700),
                  ),
                  Text('Общая доходность', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Статистика
            Row(children: [
              Expanded(child: _statCard('Сделок', result.totalTrades.toString(), Icons.swap_horiz)),
              const SizedBox(width: 12),
              Expanded(child: _statCard('Win Rate', '${result.winRate.toStringAsFixed(1)}%', Icons.trending_up)),
            ]),
            const SizedBox(height: 16),

            // График equity curve
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Equity Curve',
                    style: TextStyle(color: AppTheme.textPrimary, fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 200,
                    child: LineChart(
                      LineChartData(
                        gridData: FlGridData(
                          show: true,
                          getDrawingHorizontalLine: (_) => const FlLine(color: AppTheme.border, strokeWidth: 0.5),
                          getDrawingVerticalLine: (_) => const FlLine(color: AppTheme.border, strokeWidth: 0.5),
                        ),
                        titlesData: FlTitlesData(
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 50,
                              getTitlesWidget: (value, meta) => Text(
                                '\$${value.round()}',
                                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 10),
                              ),
                            ),
                          ),
                          bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        ),
                        borderData: FlBorderData(show: false),
                        lineBarsData: [
                          LineChartBarData(
                            spots: result.equityCurve.asMap().entries.map((e) =>
                              FlSpot(e.key.toDouble(), e.value.balance)).toList(),
                            isCurved: true,
                            color: isProfit ? AppTheme.green : AppTheme.red,
                            barWidth: 2,
                            dotData: const FlDotData(show: false),
                            belowBarData: BarAreaData(
                              show: true,
                              color: (isProfit ? AppTheme.green : AppTheme.red).withOpacity(0.1),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Новый бэктест'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: AppTheme.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppTheme.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Icon(icon, color: AppTheme.purple, size: 16),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
        ]),
        const SizedBox(height: 8),
        Text(value,
          style: const TextStyle(color: AppTheme.textPrimary, fontSize: 22, fontWeight: FontWeight.w600)),
      ],
    ),
  );
}
