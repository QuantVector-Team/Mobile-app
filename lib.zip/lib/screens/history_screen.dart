import 'package:flutter/material.dart';
import '../theme.dart';
import '../services/api_service.dart';
import '../models/history_item.dart';

class HistoryScreen extends StatefulWidget {
  final String token;
  const HistoryScreen({super.key, required this.token});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<HistoryItem> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final items = await ApiService.getHistory(widget.token);
      setState(() { _items = items; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString().replaceAll('Exception: ', ''); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {}),
        ],
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppTheme.purple))
        : _error != null
          ? Center(child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, color: AppTheme.red, size: 48),
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: AppTheme.textSecondary), textAlign: TextAlign.center),
                const SizedBox(height: 16),
                TextButton(onPressed: _load, child: const Text('Повторить')),
              ],
            ))
          : _items.isEmpty
            ? const Center(child: Text('История пуста', style: TextStyle(color: AppTheme.textSecondary)))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _items.length,
                itemBuilder: (_, i) => _HistoryCard(item: _items[i]),
              ),
    );
  }
}

class _HistoryCard extends StatelessWidget {
  final HistoryItem item;
  const _HistoryCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final isProfit = item.profitPercent >= 0;
    final profitColor = isProfit ? AppTheme.green : AppTheme.red;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        children: [
          // Заголовок
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item.strategyName,
                    style: const TextStyle(color: AppTheme.textPrimary, fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(item.symbol,
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                ]),
                Text(item.date,
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
              ],
            ),
          ),

          // Разделитель
          const Divider(height: 1, color: AppTheme.border),

          // Результат
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  Icon(isProfit ? Icons.trending_up : Icons.trending_down, color: profitColor, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    '${isProfit ? '+' : ''}${item.profitPercent.toStringAsFixed(2)}%',
                    style: TextStyle(color: profitColor, fontSize: 22, fontWeight: FontWeight.w700),
                  ),
                ]),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text('ID: ${item.testId}',
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
