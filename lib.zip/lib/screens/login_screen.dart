import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme.dart';
import '../services/api_service.dart';
import 'backtest_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _isLogin = true; // true = вход, false = регистрация
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    setState(() { _loading = true; _error = null; });
    try {
      final user = _isLogin
          ? await ApiService.login(_usernameCtrl.text.trim(), _passwordCtrl.text)
          : await ApiService.register(_usernameCtrl.text.trim(), _passwordCtrl.text);

      // Сохраняем токен
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', user.token);
      await prefs.setInt('user_id', user.userId);

      if (mounted) {
        Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => BacktestScreen(token: user.token)));
      }
    } catch (e) {
      setState(() { _error = e.toString().replaceAll('Exception: ', ''); });
    } finally {
      setState(() { _loading = false; });
    }
  }

  void _guestLogin() {
    Navigator.pushReplacement(context,
      MaterialPageRoute(builder: (_) => const BacktestScreen(token: '')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 1.2,
            colors: [Color(0xFF1A0A2E), AppTheme.bg],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Логотип
                  Container(
                    width: 80, height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppTheme.purple.withOpacity(0.4), width: 1.5),
                      color: AppTheme.surface,
                    ),
                    child: const Center(
                      child: Text('A',
                        style: TextStyle(
                          color: AppTheme.purple,
                          fontSize: 36,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text('CryptoBacktest',
                    style: TextStyle(color: AppTheme.textPrimary, fontSize: 22, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  const Text('Тестируй стратегии',
                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
                  const SizedBox(height: 40),

                  // Карточка формы
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Переключатель Вход / Регистрация
                        Container(
                          decoration: BoxDecoration(
                            color: AppTheme.card,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              _tab('Вход', _isLogin, () => setState(() => _isLogin = true)),
                              _tab('Регистрация', !_isLogin, () => setState(() => _isLogin = false)),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),

                        TextField(
                          controller: _usernameCtrl,
                          style: const TextStyle(color: AppTheme.textPrimary),
                          decoration: const InputDecoration(
                            hintText: 'Имя пользователя',
                            prefixIcon: Icon(Icons.person_outline, color: AppTheme.textSecondary, size: 20),
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _passwordCtrl,
                          obscureText: true,
                          style: const TextStyle(color: AppTheme.textPrimary),
                          decoration: const InputDecoration(
                            hintText: 'Пароль',
                            prefixIcon: Icon(Icons.lock_outline, color: AppTheme.textSecondary, size: 20),
                          ),
                        ),

                        if (_error != null) ...[
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppTheme.red.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: AppTheme.red.withOpacity(0.3)),
                            ),
                            child: Text(_error!,
                              style: const TextStyle(color: AppTheme.red, fontSize: 13),
                              textAlign: TextAlign.center),
                          ),
                        ],
                        const SizedBox(height: 20),

                        ElevatedButton(
                          onPressed: _loading ? null : _submit,
                          child: _loading
                              ? const SizedBox(width: 20, height: 20,
                                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                              : Text(_isLogin ? 'Войти' : 'Зарегистрироваться'),
                        ),
                        const SizedBox(height: 12),

                        TextButton(
                          onPressed: _guestLogin,
                          child: const Text('Войти как гость',
                            style: TextStyle(color: AppTheme.textSecondary)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _tab(String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? AppTheme.purple : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: active ? Colors.white : AppTheme.textSecondary,
              fontWeight: active ? FontWeight.w600 : FontWeight.normal,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }
}
